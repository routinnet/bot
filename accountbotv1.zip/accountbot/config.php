<?php error_reporting(E_ALL & ~E_NOTICE);
define('TOKEN','561390324'); // توکن ربات
define('HOST','localhost'); // بدون تغییر
define('USERNAME','hfilebot'); // یوزرنیم دیتابیس
define('PASSWORD','xnE'); // پسورد دیتابیس
define('DBNAME','hfilebot'); // نام دیتابیس
define('ADMIN',854945237); // ایدی عددی ادمین اول را از بات @userinfobot بگیرید
define('CHANNEL','@sss'); // آیدی کانال. برای قفل کانال حتما ربات را در کانال ادمین کنید
define('botid','bod_bot'); // آیدی ربات
define('ZARINPALMID','333333'); // مرچنت کد زرین پال
define('NEXTPAYID','333333'); // مرچنت کد نکست پی
define('DESC','ربات تلگرام فروش اکانت پولی');
define('baseURI','https://site.com/accountbot/'); // آدرس ربات روی هاست
$cardinfo = "شماره کارت 6037 به نام فلانی بانک ما";
$supportus = "@supp"; // یوزرنیم پشتیبانی